import pandas as pd
from matplotlib.backends.backend_pdf import PdfPages
import matplotlib.pyplot as plt
import os
# Lista vuota per memorizzare i dati
data = []

# Apri il file in modalità lettura
with open("./saved/test_result/test_loss_completo.txt", "r") as file:
    # Leggi ogni riga del file
    for line in file:
        # Dividi la riga in base ai delimitatori ";"
        tokens = line.split(";")
        # Estrai i valori dei parametri
        g_params = tokens[0].strip().split(", ")[1::2]  # Rimuovi "G params" e splitta per "," per ottenere i valori
        m_params = tokens[1].strip().split(", ")[1::2]  # Rimuovi "M params" e splitta per "," per ottenere i valori
        # Estrai train_perc e val_perc utilizzando un approccio diverso
        train_val_tokens = tokens[2].split(": ")
        train_perc = float(train_val_tokens[1].split(',')[0])
        val_perc = float(train_val_tokens[2].split()[0])
        print(train_val_tokens)
        print(train_val_tokens[2])
        avg_loss = float(train_val_tokens[3].split()[0])
        
        perc_dati_copiati=train_val_tokens[4].split('\n')[0]
        
      
        # Aggiungi i valori alla lista dei dati
        data.append(g_params + m_params + [train_perc, val_perc, avg_loss,perc_dati_copiati])

# Definisci i nomi delle colonne per il DataFrame
col_names = ['g_emb_dim', 'g_n_heads', 'g_n_layers', 'm_emb_dim', 'm_n_heads', 'm_n_layers', 'train_perc', 'val_perc', 'avg_loss','perc_dati_copiati']

# Crea il DataFrame pandas utilizzando i dati e i nomi delle colonne
df = pd.DataFrame(data, columns=col_names)
styled_df = df.style.background_gradient(cmap='coolwarm', subset=['avg_loss'])
styled_df

output_dir = './saved/test_result'  # Specifica la cartella di destinazione
output_file = os.path.join(output_dir, 'result_test_comp.pdf')  # Percorso completo del file PDF
# Crea un oggetto PdfPages per salvare il DataFrame in un file PDF
with PdfPages(output_file) as pdf:
    # Crea una figura vuota
    fig = plt.figure(figsize=(10, 6))
    # Aggiungi il DataFrame alla figura con stile personalizzato
    ax = fig.add_subplot(111, frame_on=False)
    ax.axis('off')
    ax.table(cellText=df.values, colLabels=df.columns, loc='center', cellLoc='center')
    # Salva la figura nella pagina del PDF
    pdf.savefig(fig, bbox_inches='tight')

