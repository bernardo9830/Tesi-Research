# Tesi Magistrale in Matematica 
Dipartimento di Matematica e Computer Science (DeMaCS) 

**Candidato**: Bernardo Valente

**Tematica**: Definizione di un framework basato su Deep Learning per la violazione del copyright 

Nella cartella config abbiamo diverse configurazioni dei parametri del modello e del generatore.


Dal file config_1.json al file config_4.json manteniamo il numero di layers e il numero di heads costante a 1 e aumentiamo la dimensione dell'embedding in questo modo: 2--4--32--128


Dal file config_5.json al file config_10 i parametri cambiano in questo modo: manteniamo costante il numero di heads, e aumento i layers nel seguente modo: 6--12--24 rispettivamente per i valori di dimensione dell' emebedding 2--128 (rispettivamente il caso semplice e il caso limite)


Dal file config_11.json al file config_16.json i parametri cambiano in questo modo: manteniamo costante il numero di layers a 1, e aumento il numero di head in questo modo: 4--8--16 rispettivamente per i valori di dimensione dell'embedding 16--128.

Nel file config_17.json aumentiamo la complessità generale del modello e del generatore: dim_embedding = 128, n_layers = 24, n_heads = 16.