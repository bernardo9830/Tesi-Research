import torch
from utils.dataloader import load, make_dataloader
import json
import sys
import os
from model.generator_G import TransformerWithPE as Transformer_G
from model.model_M import TransformerWithPE as Transformer_M
from model.trainer import Trainer
from model.trainer_m import Trainer_model
import glob


def main(file_path):
    with open(file_path, 'r') as fp:
        params = json.load(fp)

    seed = params["SEED"]
    batch_size = params["batch_size"]
    dataset = load(params["dataset_path"])
    seq_length = params["seq_length"]
    dataloader_g, train_loader_m, val_loader_m = make_dataloader(dataset, seed, batch_size, seq_length, params)

    if "CUDA_VISIBLE_DEVICES" not in os.environ:
        os.environ["CUDA_VISIBLE_DEVICES"] = params["n_gpu"]

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    params["device"] = device
    #embed_dim = params["embed_dim"]
    #num_heads = params["num_heads"]
    #num_layers = params["num_layers"]
    #best_path_mod = params["BEST_PATH_MOD"]
    #num_features = dataset.shape[1]
    split_train = params["split_train"]
    split_val = params["split_val"]

    embed_dim_m = params["embed_dim_m"]
    num_heads_m = params["num_heads_m"]
    num_layers_m = params["num_layers_m"]

    embed_dim_g = params["embed_dim_g"]
    num_heads_g = params["num_heads_g"]
    num_layers_g = params["num_layers_g"]

    best_path_mod = f"best_model_M_emb_dim_{embed_dim_m}_n_heads_{num_heads_m}_n_layers_{num_layers_m}_train_perc_{split_train}_val_perc_{split_val}.pt"
    last_path_mod = f"last_model_M_emb_dim_{embed_dim_m}_n_heads_{num_heads_m}_n_layers_{num_layers_m}_train_perc_{split_train}_val_perc_{split_val}.pt"
    
    best_path_gen = f"best_model_G_emb_dim_{embed_dim_g}_n_heads_{num_heads_g}_n_layers_{num_layers_g}_train_perc_{split_train}_val_perc_{split_val}.pt"
    last_path_gen = f"last_model_G_emb_dim_{embed_dim_g}_n_heads_{num_heads_g}_n_layers_{num_layers_g}_train_perc_{split_train}_val_perc_{split_val}.pt"

    if not os.path.exists(params["MODEL_FOLDER"]):
        os.mkdir(params["MODEL_FOLDER"])

    if not os.path.exists(os.path.join(params["MODEL_FOLDER"], 'models')):
        os.mkdir(os.path.join(params["MODEL_FOLDER"], 'models'))

    params["BEST_PATH_MOD"]= os.path.join(params["MODEL_FOLDER"], 'models',  best_path_mod)
    params["LAST_PATH_MOD"]= os.path.join(params["MODEL_FOLDER"], 'models', last_path_mod)
    params["BEST_PATH_GEN"]= os.path.join(params["MODEL_FOLDER"], 'models', best_path_gen)
    params["LAST_PATH_GEN"]= os.path.join(params["MODEL_FOLDER"], 'models', last_path_gen)
    num_features = dataset.shape[1]

    if not os.path.exists(os.path.join(params["MODEL_FOLDER"], 'results')):
        os.mkdir(os.path.join(params["MODEL_FOLDER"], 'results'))

    if not os.path.exists(os.path.join(params["MODEL_FOLDER"], 'plot')):
        os.mkdir(os.path.join(params["MODEL_FOLDER"], 'plot'))

    plot_path_loss_g = f'loss_g_emb_dim_{embed_dim_g}_n_heads_{num_heads_g}_n_layers_{num_layers_g}_train_perc_{split_train}_val_perc_{split_val}.pdf'
    plot_path_log_loss_g = f'loss_log_g_emb_dim_{embed_dim_g}_n_heads_{num_heads_g}_n_layers_{num_layers_g}_train_perc_{split_train}_val_perc_{split_val}.pdf'
    plot_path_loss_m = f'loss_m_emb_dim_{embed_dim_m}_n_heads_{num_heads_m}_n_layers_{num_layers_m}_train_perc_{split_train}_val_perc_{split_val}.pdf'
    plot_path_log_loss_m = f'loss_log_m_emb_dim_{embed_dim_m}_n_heads_{num_heads_m}_n_layers_{num_layers_m}_train_perc_{split_train}_val_perc_{split_val}.pdf'

    params["plot_path_loss_g"] = os.path.join(params["MODEL_FOLDER"], 'plot', plot_path_loss_g)
    params["plot_path_log_loss_g"] = os.path.join(params["MODEL_FOLDER"], 'plot', plot_path_log_loss_g)
    params["plot_path_loss_m"] = os.path.join(params["MODEL_FOLDER"], 'plot', plot_path_loss_m)
    params["plot_path_log_loss_m"] = os.path.join(params["MODEL_FOLDER"], 'plot', plot_path_log_loss_m)

    file_path = f'saved/results/log_emb_dim_{embed_dim_m}_n_heads_{num_heads_m}_n_layers_{num_layers_m}_train_perc_{split_train}_val_perc_{split_val}.txt'
    exp = f'G params: emb_dim, {embed_dim_g}, n_heads, {num_heads_g}, n_layers, {num_layers_g}; M params: emb_dim, {embed_dim_m}, n_heads, {num_heads_m}, n_layers, {num_layers_m}; train_perc: {split_train}, val_perc: {split_val}'

    with open(file_path, 'a') as filehandle:
        filehandle.write(exp)

    params['file_log_path'] = file_path

    # train Model M
    model = Transformer_M(num_features, num_features, embed_dim_m, num_heads_m, num_layers_m).to(device)

    trainer_m = Trainer_model(model, params)
    trainer_m.train(train_loader_m, val_loader_m)

    # train Generator G
    generator = Transformer_G(num_features, num_features, embed_dim_g, num_heads_g, num_layers_g).to(device)

    model.load_state_dict(torch.load(params["BEST_PATH_MOD"]))
    model = model.to(device)

    trainer = Trainer(generator, model, params)
    trainer.train(dataloader_g)


if __name__ == '__main__':
    directory_json = "config/"
    files = glob.glob(directory_json + "*.json")
    for file in files:
        main(file)