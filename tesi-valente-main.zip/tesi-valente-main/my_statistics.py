import pickle
import matplotlib.pyplot as plt
import numpy as np
import json
import sys

def main(config):
    with open(config) as fp:
        params = json.load(fp)

    embed_dim_m = params["embed_dim_m"]
    num_heads_m = params["num_heads_m"]
    num_layers_m = params["num_layers_m"]

    embed_dim_g = params["embed_dim_g"]
    num_heads_g = params["num_heads_g"]
    num_layers_g = params["num_layers_g"]
    with open("./saved/test_result/test_prediction/y_prediction_16.dat", "rb") as f:
        y_pred, y_true = pickle.load(f)

    print("y_pred shape", y_pred.shape)
    print("y_true shape", y_true.shape)
#y_pred = torch.rand(20,10,4)
#y_true = torch.rand(20,10,4)

    error = (y_pred - y_true)**2

# axis o dim
# sum mean
    error = error.sum(dim=-1)
    error = error.sum(dim=-1)
    error = error.clone().detach().cpu().numpy()

#out = (error < threshold).sum()

    error = np.array(list(zip(range(len(error)), error)))

    error = sorted(error, key=lambda a: a[1])
    error = np.array(error)

# print(error[:10])
    tmp_true = y_true[error[:2,0]][0][0]
    tmp_pred = y_pred[error[:2,0]][0][0]

    print("y true\n", y_true[error[:2,0]][0][0][:51])
    print("y pred\n", y_pred[error[:2,0]][0][0][:51])
    print(((tmp_true-tmp_pred)**2).sum())

    threshold = 0.5 * np.ones(len(error))
    th = 0.5

    count = 0
    sort = sorted(error[:, 1], reverse=True)

    for err in sort:
        if err <= th:
            count += 1
    percentage_below_threshold = (count / len(error)) * 100
    print(percentage_below_threshold)




    plt.figure()
    plt.grid()
    plt.yscale("log")
    plt.ylabel('Error')
    plt.grid(linewidth=0.2)
    min_error_ = min(sort)
    index_min = sort.index(min(sort))
    print(min_error_)
    
    plt.plot(range(0, len(error)), threshold)
    plt.scatter(index_min, min_error_, color='red', label='Min Error')
    plt.text(index_min, min_error_, f'min error: {min_error_:.2f}', va='bottom', ha='right', fontsize=6, transform=plt.gca().transData)
    plt.plot(range(0, len(error)), sort)
    plt.text(0, 0.1, f'Percentuale sotto la soglia: {percentage_below_threshold:.2f}%', transform=plt.gca().transAxes, va='center')
    plt.title(f'Test per il modello con dimensione embedding:{embed_dim_g},n head:{num_heads_g}, n_layers:{num_layers_g}')
    plt.savefig(f"./saved/test_result/test_prediction/new_test_prediction/out_log_dim_{embed_dim_g}_n_head_{num_heads_g}_num_layers_{num_layers_g}.pdf")

if __name__ == '__main__':
    main(sys.argv[1])

