import pickle
import matplotlib.pyplot as plt
import numpy as np
import torch

with open("./saved/test_result/test_prediction/y_prediction_16.dat", "rb") as f:
    y_pred, y_true = pickle.load(f)

print("y_pred shape", y_pred.shape)
print("y_true shape", y_true.shape)
#y_pred = torch.rand(20,10,4)
#y_true = torch.rand(20,10,4)

#error = (y_pred - y_true)**2

# axis o dim
# sum mean


error = torch.sqrt(torch.mean((y_pred - y_true) ** 2, dim=(0, 1)))
error = error.sum(dim=-1)
error = error.sum(dim=-1)

# Soglia di errore (ad esempio, 3 volte l'RMSE medio)
threshold = 0.1 * torch.mean(error)

# Conteggio dei punti oltre la soglia
count = torch.sum(error > threshold)

print("RMSE medio:", torch.mean(error))
print("Punti oltre la soglia:", count)

# Plotting dell'errore RMSE
plt.figure()
plt.plot(error, label='RMSE')
plt.axhline(threshold, color='r', linestyle='--', label='Soglia')
plt.xlabel('Campione')
plt.ylabel('RMSE')
plt.title('Errore RMSE e soglia')
plt.legend()
plt.grid(True)
plt.show()
plt.savefig("./saved/plot/out_log8.pdf")