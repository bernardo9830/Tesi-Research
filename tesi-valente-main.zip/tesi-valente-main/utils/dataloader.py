import numpy as np
import torch
import pandas as pd
from torch.utils.data import DataLoader
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import MinMaxScaler
from torch.utils.data import TensorDataset
from utils.utils import split_sequence


def load(dataset_path):
    dataset = pd.read_csv(dataset_path)
    dataset.drop(columns=['Unnamed: 0', 'timestamp', 'machine_status', 'sensor_15'], inplace=True)
    columns = dataset.columns
    dataset = dataset.dropna()

    scaler = MinMaxScaler()
    dataset = scaler.fit_transform(dataset)
    dataset = pd.DataFrame(dataset, columns=columns)
    return dataset


def load_and_partition_data(dataset, seq_length) -> tuple[np.ndarray, int]:
    """Loads the given data and partitions it into sequences of equal length.

    Args:
        dataset: pandas dataframe dataset
        seq_length: length of the generated sequences

    Returns:
        tuple[np.ndarray, int]: tuple of generated sequences and number of
            features in dataset
    """
    # data = dataset
    num_features = dataset.shape[1]

    num_sequences = dataset.shape[0] // seq_length
    sequences = np.empty((num_sequences, seq_length, num_features))

    for i in range(0, num_sequences):
        # [sequence_length, num_features]
        start_idx = i * seq_length
        end_idx = (i + 1) * seq_length
        sample = dataset.iloc[start_idx:end_idx].values
        sequences[i] = sample

    return sequences, num_features


def make_datasets(sequences: np.ndarray, seed, params):
    """Create train, validation and test dataset.

    Args:
        sequences: sequences to use [num_sequences, sequence_length, num_features]
        seed:
    Returns:
        tuple[TensorDataset,TensorDataset, TensorDataset]: train, validation and test dataset
    """
    # Split sequences into train and test split
    split_train = params["split_train"]
    split_val = params["split_val"]
    train_m, val_m = train_test_split(sequences, test_size=0.5, random_state=seed,shuffle=True)
    _, train_extra = train_test_split(train_m, test_size=split_train, random_state=seed,shuffle=True)
    _, val_extra = train_test_split(val_m, test_size=split_val, random_state=seed,shuffle=True)
    g = np.concatenate((train_extra, val_extra))
    # train_G, val_G = train_test_split(G, test_size=0.5, random_state=seed)
    # train, val = train_test_split(train, test_size=0.2, random_state=seed)

    return torch.Tensor(g), torch.Tensor(train_m), torch.Tensor(val_m)


def make_dataloader(dataset, seed, batch_size, seq_length, params):

    sequences, num_features = load_and_partition_data(dataset, seq_length)
    set_g, train_set_m, val_set_m = make_datasets(sequences, seed, params)

    x_train_g, y_shift_train_g, y_train_g = split_sequence(set_g)

    x_train_m, y_shift_train_m, y_train_m = split_sequence(train_set_m)
    x_val_m, y_shift_val_m, y_val_m = split_sequence(val_set_m)

    dataset_g = TensorDataset(y_train_g, x_train_g, y_shift_train_g, y_train_g)
    train_dataset_m = TensorDataset(x_train_m, y_shift_train_m, y_train_m)
    val_dataset_m = TensorDataset(x_val_m, y_shift_val_m, y_val_m)

    dataloader_g = DataLoader(dataset_g, batch_size=batch_size, shuffle=True)
    train_loader_m = DataLoader(train_dataset_m, batch_size=batch_size, shuffle=True)
    val_loader_m = DataLoader(val_dataset_m, batch_size=batch_size, shuffle=True)

    return dataloader_g, train_loader_m, val_loader_m






